#ifndef PAGO_H_INCLUDED
#define PAGO_H_INCLUDED
#include"Fecha.h"
class Pago{
    private:
        Fecha *FechaPago;
        float MontoPago;
    public:
        Pago(Fecha *FP, float MP){
            this->FechaPago=FP;
            this->MontoPago=MP;
        }
        Fecha *getFechaPago(){
            return this->FechaPago;
        }
        float getMontoPago(){
            return this->MontoPago;
        }


};




#endif // PAGO_H_INCLUDED
