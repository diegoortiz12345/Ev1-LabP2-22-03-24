#ifndef CLIENTE_H_INCLUDED
#define CLIENTE_H_INCLUDED
#include<string>
using namespace std;

class Cliente{
    private:
        int idCliente;
        string nombre;
        string apellido;
    public:
        Cliente(int i, string n, string a){
            this->idCliente= i;
            this->nombre=n;
            this->apellido=a;
        };
        int getIdCliente(){
            return idCliente;
        }
        string getNombre(){
            return nombre;
        }
        string getApellido(){
            return apellido;
        }



} ;



#endif // CLIENTE_H_INCLUDED
