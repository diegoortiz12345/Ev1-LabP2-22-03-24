#include <iostream>
using namespace std;
#include"Cliente.h"
#include"Prestamo.h"
#include<stdlib.h>
#define TML 5

int menu(){
    int opc;
    cout<<"MENU DE OPCIONES\n";
    cout<<"1. Agregar clientes a la lista\n";
    cout<<"2. Agregar pr�stamo a la lista\n.";
    cout<<"3. Hacer pagos de pr�stamos\n";
    cout<<"4. Mostrar lista de clientes\n";
    cout<<"5. Mostrar lista de prestamos\n";
    cout<<"6. Mostrar detalles del pr�stamo\n";
    cout<<"7. Salir\n\n";
    cout<<"DIGITE UNA OPCION: ";
    cin>>opc;
    return opc;

}
Cliente *BuscarCliente(Cliente *lst[], int cont, int db){
    bool encontrado=false;
    int contar=0;
    Cliente *cli=NULL;
    while (contar<cont && !encontrado){
        if (lst[contar]->getIdCliente() == db){
            encontrado = true;
            cli=lst[contar];
        }
        else{
            contar++;
        }
    }
    return cli;
}
Prestamo *BuscarPrestamo(Prestamo *lst[], int cont, int db){
    bool encontrado = false;
    int contar=0;
    Prestamo *pM=NULL;
    while (contar<cont && !encontrado){
        if (lst[contar]->getNumeroPrestamo() == db){
            encontrado = true;
            pM=lst[contar];
        }
        else{
            contar++;
        }
    }
    return pM;
}
Cliente *agregarCliente(){
    int id;
    string n,a;
    Cliente *cli;
    cout<<"Cree un id del cliente: ";
    cin>>id;
    cout<<"Digite el nombre del cliente: ";
    cin>>n;
    cout<<"Digite el apellido del cliente: ";
    cin>>a;
    cli=new Cliente(id, n,a);
    return cli;
}
Prestamo *agregarPrestamo(Cliente *cli){
    int np;
    int d, m, a;
    Fecha *fa;
    float ma;
    Prestamo *ptO;
    cout<<"Cree un codigo del prestamo: ";
    cin>>np;
    cout<<"Digite el dia de aprobacion: \n";
    cin>>d;
    cout<<"Digite el mes de aprobacion: \n";
    cin>>m;
    cout<<"Digite el anio de aprobacion: \n";
    cin>>a;
    fa = new Fecha(d,m,a);
    cout<<"Digite el monto que se aprobara: ";
    cin>>ma;
    ptO=new Prestamo(np, cli, fa, ma);
    return ptO;
}
void registrarPago(Prestamo *_Prestamo){
    int d, m, a;
    Fecha *fp;
    float mp;
    Pago *Pag;
    cout<<"Digite el dia del pago: \n";
    cin>>d;
    cout<<"Digite el mes: \n";
    cin>>m;
    cout<<"Digite el anio: \n";
    cin>>a;
    cout<<"Digite el monto a pagar: ";
    cin>>mp;
    fp=new Fecha(d, m, a);
    Pag=new Pago(fp, mp);
    _Prestamo->hacerPago(Pag);
}
void verDetalles(Prestamo *prtmo){
    cout<<"El numero: " << prtmo->getNumeroPrestamo()<<endl;
    cout<<"Cliente: " << prtmo->getcliente()->getNombre() << " " << prtmo->getcliente()->getApellido() << endl;
    cout<<"Fecha Aprobacion: ";
    prtmo->getFechaAprobacion()->mostrarFecha();
    cout<<"\nMonto aprobado: " << prtmo->getMontoAprobado()<<endl;
    cout<<"Saldo pendiente: " << prtmo->getSaldoPendiente()<< endl;
    if (prtmo->getContadorPagos() == 0){
        cout<<"No tiene pagos registrados\n";
    }
    else{
        Pago **lista = prtmo->getLstPagos();
        cout<<"No\tFecha\tMonto\n";
        for (int i=0; i<prtmo->getContadorPagos();i++){
            cout<<(i+1) << "\t";
            lista[i]->getFechaPago()->mostrarFecha();
            cout<< "\t" << lista[i]->getMontoPago()<< endl;
        }
    }
}
int main()
{
    Cliente *lstClientes[TML];
    Prestamo *lstPrestamo[TML];
    Cliente *Cli=NULL;
    Prestamo *Pres=NULL;
    int op, cantPres=0, cantCli=0, idCli, idPres;
    do
    {
        system("cls");
        op=menu();
        switch(op){
            case 1://Agregar clientes a lista
                if(cantCli<TML){
                    lstClientes[cantCli]=agregarCliente();
                    cantCli++;
                }
                else{
                    cout<<"La lista esta llena\n";
                }
                break;
            case 2://Agregar pr�stamo a la lista
                if(cantPres<TML){
                    cout<<"Digite el id del cliente\n";
                    cin>>idCli;
                    Cli=BuscarCliente(lstClientes, cantCli, idCli);
                    if(Cli){
                        lstPrestamo[cantPres]=agregarPrestamo(Cli);
                        cantPres++;
                        cout<<"El prestamo se registro con exito\n";
                    }
                    else{
                        cout<<"El cliente no existe, no se puede agregar el prestamo\n";
                    }
                }
                else{
                    cout<<"La lista esta llena\n";
                }
                break;
            case 3://Hacer pagos de prestamo
                 {
                cout<<"Digite el codigo de prestamo: \n";
                cin>>idPres;
                Pres=BuscarPrestamo(lstPrestamo, cantPres, idPres);
                if(Pres){
                    registrarPago(Pres);
                    cout<<"El pago se registro con exito\n";
                }
                else{
                    cout<<"El prestamo no existe\n";
                }
            }
                break;
            case 4://Mostrar lista de clientes
                 if (cantCli == 0){
                    cout<<"La lista esta vacia\n";
                }
                else{
                    cout<< "Id\tNombre\tApellido\n";
                    for (int i=0;i<cantCli;i++){
                        cout<<lstClientes[i]->getIdCliente() << "\t";
                        cout<<lstClientes[i]->getNombre() << "\t";
                        cout<<lstClientes[i]->getApellido() << "\n";
                    }
                }
                break;
            case 5://Mostrar lista de prestamos
                    if(cantPres==0){
                    cout<<"La lista esta vacia\n";
                }
                else{
                    cout <<"No\tCliente\t\tFecha\t\tMonto\t\tSaldo\n";
                    for(int i=0; i<cantPres;i++){
                        cout<<lstPrestamo[i]->getNumeroPrestamo()<< "\t";
                        cout<<lstPrestamo[i]->getcliente()->getNombre() << " "<<lstPrestamo[i]->getcliente()->getApellido()<< "\t";
                        lstPrestamo[i]->getFechaAprobacion()->mostrarFecha();
                        cout<< "\t \t \t \t \t" <<lstPrestamo[i]->getMontoAprobado()<< "\t \t";
                        cout<< lstPrestamo[i]->getSaldoPendiente()<<endl;
                    }
                }
                break;
            case 6://Mostrar detalles del pr�stamo
                 cout<<"Digite el numero de prestamo: ";
                cin>>idPres;
                Pres = BuscarPrestamo(lstPrestamo, cantPres, idPres);
                if(Pres){
                    verDetalles(Pres);
                }
                else{
                    cout<<"El prestamo no existe";
                }
                break;
            case 7://Salir
                cout<<"Salu...\n";
                break;
            default://Agregar clientes a lista
                cout<<"Error, la opcion no existe";
        }
        system("pause");
    }while(op!=7);

    return 0;
}
